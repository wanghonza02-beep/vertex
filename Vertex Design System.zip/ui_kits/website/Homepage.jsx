const { Button, IconButton, Icon, Tag, Badge, Card, Logo, HeadlineSplit, SpecNumber, Eyebrow, SectionTitle, BlueprintRule, MediaFrame, Input, Textarea, Select, Checkbox, RadioGroup, Switch, SiteHeader, SiteFooter, Tabs, Dialog, Toast, Tooltip, BuildCard, SpecTable, BeforeAfter, AcousticPlayer } = window.VertexDesignSystem_24ef46;

function Hero({ onView, onCommission }) {
  return (
    <section style={{ position:'relative', minHeight:620, display:'flex', alignItems:'center', borderBottom:'var(--border-rule)', overflow:'hidden' }}>
      <div style={{ position:'absolute', inset:0, backgroundImage:'var(--grid-blueprint)' }} />
      <div style={{ position:'absolute', inset:0, background:'var(--scrim-left)' }} />
      <div style={{ position:'relative', padding:'0 var(--gutter-page-wide)', maxWidth:900 }}>
        <Eyebrow>Vertex — Restomod atelier</Eyebrow>
        <HeadlineSplit size="hero" luxury="Immortal Icons." tech="Modern Muscle." style={{ margin:'var(--space-6) 0 var(--space-8)' }} />
        <p style={{ font:'var(--type-body-lg)', fontSize:'var(--size-subtitle)', color:'var(--text-body)', maxWidth:'var(--measure-text)', margin:'0 0 var(--space-10)' }}>
          We do not build cars. We resurrect legends — the most iconic chassis in automotive history, rebuilt at the exact point where character meets engineering.
        </p>
        <div style={{ display:'flex', gap:'var(--space-4)', alignItems:'center', flexWrap:'wrap' }}>
          <Button size="lg" onClick={onView}>View the build</Button>
          <Button size="lg" variant="secondary" onClick={onCommission} iconRight={<Icon name="arrow-right" size={14} />}>Request a build slot</Button>
        </div>
      </div>
      <div style={{ position:'absolute', right:'var(--gutter-page-wide)', bottom:'var(--space-10)', display:'flex', alignItems:'center', gap:'var(--space-3)' }}>
        <span style={{ width:2, height:44, background:'var(--corsa-red)' }} />
        <span style={{ fontFamily:'var(--font-mono)', fontSize:'var(--size-label-sm)', letterSpacing:'var(--tracking-label)', textTransform:'uppercase', color:'var(--corsa-red)' }}>Scroll</span>
      </div>
    </section>
  );
}

function Philosophy() {
  return (
    <section style={{ padding:'var(--space-24) var(--gutter-page-wide)', borderBottom:'var(--border-rule)' }}>
      <div style={{ display:'grid', gridTemplateColumns:'minmax(0,1fr) minmax(0,1.1fr)', gap:'var(--space-20)' }}>
        <div>
          <SectionTitle meta="Since 2019">Why we exist</SectionTitle>
          <p style={{ font:'var(--type-body-lg)', color:'var(--text-body)', margin:'0 0 var(--space-6)' }}>
            Perfection isn't found in the newest technology, and it isn't found in old-world nostalgia either — it's found at the vertex, the point where both meet.
          </p>
          <p style={{ font:'var(--type-body)', color:'var(--text-body)', margin:0 }}>
            Modern hypercars have become sterile and digitalized. Even a limited-run supercar is still one of hundreds of nearly identical VINs. The icons of the past carry raw soul and timeless design, but are held back by outdated performance. We don't take that soul away. We elevate it.
          </p>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'var(--space-12) var(--space-16)', alignContent:'center' }}>
          <SpecNumber value="1,000" unit="hrs" label="Minimum per build" tone="gold" countUp />
          <SpecNumber value={4} label="Builds delivered" countUp />
          <SpecNumber value={1} unit="of 1" label="Every commission" />
          <SpecNumber value={2} label="Slots remaining, 2026" />
        </div>
      </div>
    </section>
  );
}

function Inventory({ builds, onSelect }) {
  const [availableOnly, setAvailableOnly] = React.useState(false);
  const shown = availableOnly ? builds.filter(b => b.status !== 'sold') : builds;
  return (
    <section style={{ padding:'var(--space-24) var(--gutter-page-wide)', borderBottom:'var(--border-rule)' }}>
      <SectionTitle meta={shown.length + ' builds'}>Available builds</SectionTitle>
      <div style={{ display:'flex', justifyContent:'flex-end', marginBottom:'var(--space-8)' }}>
        <Switch label="Available only" checked={availableOnly} onChange={setAvailableOnly} />
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3, minmax(0,1fr))', gap:'var(--space-8)' }}>
        {shown.map(b => (
          <BuildCard key={b.id} code={b.code + ' — ' + b.year + ' ' + b.donorName} title={b.title}
            donor={b.donor} status={b.status} power={b.power} hours={b.hours} onSelect={() => onSelect(b)} />
        ))}
      </div>
    </section>
  );
}

function ArchiveTeaser({ onArchive }) {
  return (
    <section style={{ padding:'var(--space-24) var(--gutter-page-wide)', display:'flex', alignItems:'flex-end', justifyContent:'space-between', gap:'var(--space-16)', flexWrap:'wrap' }}>
      <div style={{ maxWidth:520 }}>
        <Eyebrow tone="brass">The legacy archive</Eyebrow>
        <HeadlineSplit size="section" luxury="Every build, on record." style={{ margin:'var(--space-5) 0 var(--space-6)' }} />
        <p style={{ font:'var(--type-body)', color:'var(--text-body)', margin:'0 0 var(--space-8)' }}>
          Total man-hours, donor provenance and historical backstory for every car that has left the studio.
        </p>
        <Button variant="secondary" onClick={onArchive} iconRight={<Icon name="arrow-up-right" size={14} />}>Enter the archive</Button>
      </div>
      <div style={{ display:'flex', gap:'var(--space-16)' }}>
        <SpecNumber value="4,603" label="Hours invested" size="lg" tone="gold" countUp />
        <SpecNumber value={7} label="Donors sourced" size="lg" countUp />
      </div>
    </section>
  );
}

function Homepage({ builds, onSelect, onNavigate }) {
  return (
    <React.Fragment>
      <Hero onView={() => onSelect(builds[0])} onCommission={() => onNavigate('commission')} />
      <Philosophy />
      <Inventory builds={builds} onSelect={onSelect} />
      <ArchiveTeaser onArchive={() => onNavigate('archive')} />
    </React.Fragment>
  );
}
Object.assign(window, { Homepage });
